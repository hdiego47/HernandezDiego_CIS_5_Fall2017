/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on September 21, 2017, 11:23 AM
 * Purpose: To figure out how many cans of a soft drink will be required 
 *          to kill a human
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
#include <iomanip>   //Format library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants
const float LBSGRMS=453.5f;  //Conversion from pounds to grams

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float mMass=35;   //Mass of the mouse in grams
    float mKill=5;    //Grams of sweetener needed to kill a mouse
    float hWt;        //Weight of a human in lbs
    float mCoke=350;  //Mass of a can of coke in grams
    float cons=.001f; //Percentage concentration of sweetener
    float nCans;      //Number of cans of coke needed to kill a human
    
    //Input Data/Variables
    cout<<"This program calculates how many cans of coke are needed to kill"<<endl;
    cout<<"a human based on their weight"<<endl;
    cout<<"Please enter your weight in pounds (lbs)"<<endl;
    cin>>hWt;
    
    //Process or map the inputs to the outputs
    nCans=(hWt*mKill/mMass)/(mCoke*cons*1/LBSGRMS);
    
    //Display/Output all pertinent variables
    cout<<fixed<<setprecision(2)<<showpoint;
    cout<<"Your weight is "<<hWt<<" lbs"<<endl;
    cout<<"The amount of cans of coke needed to kill you is "<<nCans<<endl;
    
    //Exit the program
    return 0;
}