/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on September 5, 2017, 12:18 PM
 * Purpose: To calculate how much profit the government and the oil
 *          companies make on a gallon of gas
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float fedProf=18.4f;       //federal government profit in cents
    float stProf=36;           //State government profit in cents
    float caSlsTx=.08f;        //California sales tax
    float gasPrc=3;            //Price of a gallon of gas
    float oilComp=0.7f;        //Oil company profit
    float fedPrc,oilPrc,stPrc; //Percent of profit
    
    //Process or map the inputs to the outputs
    
    //Display/Output all pertinent variables
    
    //Exit the program
    return 0;
}