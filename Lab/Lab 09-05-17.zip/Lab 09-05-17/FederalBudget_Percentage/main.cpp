/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on September 5, 2017, 11:37 AM
 * Purpose: To find the percentage of the federal budget that goes into 
 *          NASA and the DOD
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float fedBud=3.8E12f;  //The US federal budget 3.8 Trillion $'s
    float dodBud=609e9f;   //The US Department of Defense budget 608 Billion $'s
    float nasaBud=18.4e9f; //The NASA budget 18.4 Billion $'s
    float perDod, perNasa; //The percent of the federal budget allocated to each
 
    //Process or map the inputs to the outputs
    perDod=dodBud/fedBud*100;
    perNasa=nasaBud/fedBud*100;
    
    //Display/Output all pertinent variables
    cout<<"This program calculates what percent of the federal budget goes "<<
            "into NASA and the Department of Defense (DoD)"<<endl;
    cout<<endl;
    cout<<"US Federal Budget for 2017  "<<fedBud<<"  Dollars"<<endl;
    cout<<"DoD's budget for 2017       "<<dodBud<<" Dollars"<<endl;
    cout<<"NASA's budget for 2017      "<<nasaBud<<" Dollars"<<endl;
    cout<<endl;
    cout<<"DoD's percent budget is     "<<perDod<<"%"<<endl;
    cout<<"NASA's percent budget is    "<<perNasa<<"%"<<endl;
    
    //Exit the program
    return 0;
}