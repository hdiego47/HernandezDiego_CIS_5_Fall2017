/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on October 7, 2017, 11:30 AM
 * Purpose: Three Person Shooter
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
#include <ctime>
#include <cstdlib>
#include <cmath>
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes
float pRand();

//Execution Begins Here
int main(int argc, char** argv) {
    //Set the random number seed
    srand(static_cast<unsigned int>(time(0)));
    
    //Declare Variables
    bool aliveA,aliveB,aliveC;
    float pkillA,pkillB,pkillC;
    
    //Initialize Variables
    aliveA=aliveB=aliveC=true;
    pkillA=1.0f/3;
    pkillB=1.0f/2;
    pkillC=1.0f;
    
    //Process or map the inputs to the outputs
    char aliveSm;
    do{
        if(aliveA){
            if(aliveB){
                if(pRand()<=pkillA)aliveB=false;
            }else if(aliveC){
                if(pRand()<=pkillA)aliveC=false;
            }
        }

        if(aliveB){
            if(aliveC){
                if(pRand()<=pkillB)aliveC=false;
            }else if(aliveA){
                if(pRand()<=pkillB)aliveA=false;
            }
        }

        if(aliveC){
            if(aliveA){
                if(pRand()<=pkillC)aliveA=false;
            }else if(aliveB){
                if(pRand()<=pkillC)aliveB=false;
            }
        }
        aliveSm=aliveA+aliveB+aliveC;
    }while(aliveSm>1);
    
    //Display/Output all pertinent variables
    cout<<"Aaron   is "<<(aliveA?"Alive":"Dead")<<endl;
    cout<<"Bob     is "<<(aliveB?"Alive":"Dead")<<endl;
    cout<<"Charlie is "<<(aliveC?"Alive":"Dead")<<endl;
    
    //Exit the program
    return 0;
}

float pRand(){
    
}