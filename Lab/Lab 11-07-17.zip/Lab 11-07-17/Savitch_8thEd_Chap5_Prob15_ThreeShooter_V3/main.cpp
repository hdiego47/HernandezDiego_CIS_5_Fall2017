/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on October 7, 2017, 11:30 AM
 * Purpose: Three Person Shooter
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
#include <ctime>     //Time function library
#include <cstdlib>   //srand library
#include <cmath>     //Math library
#include <iomanip>   //
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes
float pRand();
void shoot(bool,float,bool &,bool &);

//Execution Begins Here
int main(int argc, char** argv) {
    //Set the random number seed
    srand(static_cast<unsigned int>(time(0)));
    
    //Declare Variables
    bool aliveA,aliveB,aliveC;
    float pkillA,pkillB,pkillC;
    int nGames,nWinA,nWinB,nWinC;
    
    //Initialize Variables
    aliveA=aliveB=aliveC=true;
    pkillA=1.0f/3;
    pkillB=1.0f/2;
    pkillC=1.0f;
    nWinA=nWinB=nWinC=0;
    nGames=10000;
    
    //Process or map the inputs to the outputs
    for(int game=1;game<=nGames;game++){
        char aliveSm;
        do{
            shoot(aliveA,pkillA,aliveB,aliveC);

            shoot(aliveB,pkillB,aliveC,aliveA);

            shoot(aliveC,pkillC,aliveA,aliveB);

            aliveSm=aliveA+aliveB+aliveC;
        }while(aliveSm>1);
        nWinA+=aliveA;
        nWinB+=aliveB;
        nWinC+=aliveC;
        aliveA=aliveB=aliveC=1;
    }
    //Display/Output all pertinent variables
    cout<<fixed<<setprecision(4)<<showpoint;
    cout<<"Number of Games = "<<nGames<<" = "<<nWinA+nWinB+nWinC<<endl;
    cout<<"Aaron with   pkill = "<<pkillA<<" won "<<nWinA<<" times"<<endl;
    cout<<"Bob with     pkill = "<<pkillB<<" won "<<nWinB<<" times"<<endl;
    cout<<"Charlie with pkill = "<<pkillC<<" won "<<nWinB<<" times"<<endl;
    
    //Exit the program
    return 0;
}

void shoot(bool a,float pka,bool &b,bool &c){
    if(a){
            if(b){
                if(pRand()<=pka)b=false;
            }else if(c){
                if(pRand()<=pka)c=false;
            }
        }
}

float pRand(){
    
}