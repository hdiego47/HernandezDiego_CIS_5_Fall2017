/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on August 29, 2017, 12:01 PM
 * Purpose: Creating our class template
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    int x,y,z; //Numbers to be sorted
    
    //Input Data/Variables
    cout<<"This Program sorts 3 numbers from largest to smallest"<<endl;
    cout<<"Please enter three numbers you wish to sort"<<endl;
    cin>>x>>y>>z;
    cout<<endl;
    
    //Display/Output all pertinent variables
    if(x>y&&x>z){
        if(y>z)cout<<x<<","<<y<<","<<z<<endl;
        else cout<<x<<","<<z<<","<<y<<endl;
    }else if(y>x&&y>z){
        if(x>z)cout<<y<<","<<x<<","<<z<<endl;
        else cout<<y<<","<<z<<","<<x<<endl;
    }else if(z>y&&z>x){
        if(x>y)cout<<z<<","<<x<<","<<y<<endl;
        else cout<<z<<","<<y<<","<<x<<endl;
    }
    
    //Exit the program
    return 0;
}