/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on September 5, 2017, 12:18 PM
 * Purpose: To calculate how much profit the government and the oil
 *          companies make on a gallon of gas
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float fedTax=.184f;   //federal government tax in cents
    float stTax=.36f;     //State government tax in cents
    float slsTxPc=.08f;   //Percent California sales tax
    float prcPmp=2.93f;   //Price of a gallon of gas at the pump
    float oilComp=0.07f;  //Oil company profit
    float basePrc,taxPrc; //The base price and tax percent
    float totTax,         //Total tax in $/gallon
          stSlsTx,        //state sales tax in $/gallon
          oilCPrc;        //oil company percent profit
    
    //Process or map the inputs to the outputs
    basePrc=(prcPmp-fedTax-stTax)/(1+slsTxPc); //Finding the base price
    totTax=prcPmp-basePrc;                     //Finding the total tax in $'s
    taxPrc=totTax/basePrc*100;                 //Finding the tax percent
    stSlsTx=basePrc*slsTxPc;                   //Finding the state sales tax in $'s
    oilCPrc=oilComp/basePrc*100;               //Finding the percent oil company profit
    
    //Display/Output all pertinent variables
    cout<<"Known Values"<<endl;
    cout<<"Price at the pump for a gallon of gass                $"<<prcPmp<<endl;
    cout<<"Federal Tax for a gallon of gas                       $"<<fedTax<<endl;
    cout<<"State tax for a gallon of gas                         $"<<stTax<<endl;
    cout<<"Percentage sales tax for a gallon of gas              "<<slsTxPc*100<<
            "%"<<endl;
    cout<<"Oil company profit per gallon                         $"<<oilComp<<endl<<endl;
    cout<<"Unknown Values"<<endl;
    cout<<"The base price for a gallon of gas is                 $"<<basePrc<<endl;
    cout<<"The state sales tax for a gallon of gas is            $"<<stSlsTx<<endl;
    cout<<"The total tax for a gallon of gas is                  $"<<totTax<<endl;
    cout<<"The percent total tax for a gallon of gas is          "<<taxPrc<<
            "%"<<endl;
    cout<<"The percent oil company profit for a gallon of gas is "<<oilCPrc<<
            "%"<<endl;
    
    //Exit the program
    return 0;
}