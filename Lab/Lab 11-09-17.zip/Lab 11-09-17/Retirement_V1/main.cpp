/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on November 9, 2017, 12:17 PM
 * Purpose: Retirement Calculator Version 1
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
#include <iomanip>   //Format Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float salary,deposit,invRate,savings,retAcct;
    
    //Initialize Variables
    salary=100000;         //$100k
    invRate=0.05;          //5%
    savings=salary/invRate;//Required savings to retire $'s
    deposit=0.10;          //10%/year
    retAcct=0;             //Initialize the retirement account
    
    //Process or map the inputs to the outputs
    cout<<fixed<<setprecision(2)<<showpoint;
    cout<<"Retirement Table"<<endl;
    cout<<"Year     Savings  Int Earned   Deposit"<<endl;
    for(int year=2022;year<=2072;year++){
        float intErnd=invRate*retAcct;//Interest earned for the year
        float depAmt= deposit*salary;//Yearly deposit
        cout<<setw(4)<<year<<setw(12)<<retAcct<<setw(11)<<intErnd
                <<setw(11)<<depAmt<<endl;
        retAcct+=(intErnd+depAmt);
    }
    
    //Exit the program
    return 0;
}