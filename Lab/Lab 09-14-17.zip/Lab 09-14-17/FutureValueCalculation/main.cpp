/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on September 14, 2017, 11:47 PM
 * Purpose: To find the future value
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
#include <cmath>     //Math Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    unsigned short pv=100;  //The Present value in dollars
    float i=6;              //The interest rate percent
    unsigned short n;       //The number of compounding periods
    float fvPow,fvExp;      //The future value using power and exponent functions
    unsigned short rule=72; //The rule of 72
    
    //Process or map the inputs to the outputs
    n=rule/i;                 //Calculating the number of compounding periods
    i=i/100;                  //conversion to percent
    fvPow=pv*pow(1+i,n);      //finding future value using power function
    fvExp=pv*exp(n*log(1+i)); //finding future value using exponent function
    
    //Display/Output all pertinent variables
    cout<<"The present value is                             $"<<pv<<endl;
    cout<<"The interest rate is                                "<<i*100<<"%"<<endl;
    cout<<"The number of compounding periods is               "<<n<<endl;
    cout<<"The future value using the power function is     $"<<fvPow<<endl;
    cout<<"The future value using the exponent function is  $"<<fvExp<<endl;
    
    //Exit the program
    return 0;
}