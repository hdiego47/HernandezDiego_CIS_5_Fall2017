/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on September 26, 2017, 11:56 AM
 * Purpose: Confirm the results of the truth table
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    bool x,y; //Boolean Expressions
    
    //Display the heading
    cout<<"X Y !X !Y X||Y X&&Y X^Y X^Y^Y X^Y^X"<<
            " !(X||Y) !X&&!Y !(X&&Y) !X||!Y"<<endl;
    
    //Initialize Variables for the first row
    x=true;
    y=true;
    
    //Display the First row
    
    cout<<(x?'T':'F')<<" "<<(y?'T':'F')<<"  ";
    cout<<(!x?'T':'F')<<"  "<<(!y?'T':'F')<<"  ";
    cout<<(x||y?'T':'F')<<"    "<<(x&&y?'T':'F')<<"    ";
    cout<<(x^y?'T':'F')<<"    "<<(x^y^y?'T':'F')<<"     ";
    cout<<(x^y^x?'T':'F')<<"      "<<(!(x||y)?'T':'F')<<"       ";
    cout<<(!x&&!y?'T':'F')<<"      "<<(!(x&&y)?'T':'F')<<"      ";
    cout<<(!x||!y?'T':'F')<<endl;
    
     //Initialize Variables for the second row
    x=true;
    y=false;
    
    //Display the second row
    
    cout<<(x?'T':'F')<<" "<<(y?'T':'F')<<"  ";
    cout<<(!x?'T':'F')<<"  "<<(!y?'T':'F')<<"  ";
    cout<<(x||y?'T':'F')<<"    "<<(x&&y?'T':'F')<<"    ";
    cout<<(x^y?'T':'F')<<"    "<<(x^y^y?'T':'F')<<"     ";
    cout<<(x^y^x?'T':'F')<<"      "<<(!(x||y)?'T':'F')<<"       ";
    cout<<(!x&&!y?'T':'F')<<"      "<<(!(x&&y)?'T':'F')<<"      ";
    cout<<(!x||!y?'T':'F')<<endl;
    
     //Initialize Variables for the third row
    x=false;
    y=true;
    
    //Display the third row
    
    cout<<(x?'T':'F')<<" "<<(y?'T':'F')<<"  ";
    cout<<(!x?'T':'F')<<"  "<<(!y?'T':'F')<<"  ";
    cout<<(x||y?'T':'F')<<"    "<<(x&&y?'T':'F')<<"    ";
    cout<<(x^y?'T':'F')<<"    "<<(x^y^y?'T':'F')<<"     ";
    cout<<(x^y^x?'T':'F')<<"      "<<(!(x||y)?'T':'F')<<"       ";
    cout<<(!x&&!y?'T':'F')<<"      "<<(!(x&&y)?'T':'F')<<"      ";
    cout<<(!x||!y?'T':'F')<<endl;
    
     //Initialize Variables for the fourth row
    x=false;
    y=false;
    
    //Display the Fourth row
    
    cout<<(x?'T':'F')<<" "<<(y?'T':'F')<<"  ";
    cout<<(!x?'T':'F')<<"  "<<(!y?'T':'F')<<"  ";
    cout<<(x||y?'T':'F')<<"    "<<(x&&y?'T':'F')<<"    ";
    cout<<(x^y?'T':'F')<<"    "<<(x^y^y?'T':'F')<<"     ";
    cout<<(x^y^x?'T':'F')<<"      "<<(!(x||y)?'T':'F')<<"       ";
    cout<<(!x&&!y?'T':'F')<<"      "<<(!(x&&y)?'T':'F')<<"      ";
    cout<<(!x||!y?'T':'F')<<endl;
    
    //Exit the program
    return 0;
}