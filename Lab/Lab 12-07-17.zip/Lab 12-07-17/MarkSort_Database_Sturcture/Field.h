/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on December 7, 2017, 11:30 AM
 * Purpose:  Our first structure used in sorting
 */

#ifndef FIELD_H
#define FIELD_H

struct Field{
    int size; //Size of the array
    int *a;   //Array containing our data
    int *indx;//Index to the array data
};


#endif /* FIELD_H */

