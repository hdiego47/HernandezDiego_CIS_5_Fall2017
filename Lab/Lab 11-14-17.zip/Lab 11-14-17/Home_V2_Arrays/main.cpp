/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on November 14, 2017, 12:08 PM
 * Purpose: Home Calculator Version 2 With Arrays
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
#include <iomanip>   //Format Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants
const int CNVMNYR=12; //Conversion Months to Year
const int CNVPRCT=100;//Conversion to percent

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    const int SIZE=360;
    float pPrice,pDown,loanAmt[SIZE]={},intRate,mnPmt[SIZE]={},intAccm[SIZE]={};
    int nMonths;
    
    //Initialize Variables
    pPrice=350000.00f;             //Purchase Price = $350k
    pDown=0.20;                    //20%
    loanAmt[0]=pPrice*(1-pDown);   //Loan Amount $'s
    intRate=0.05;                  //Interest Rate/year
    for(int cnt=0;cnt<=360;cnt++){
        mnPmt[cnt]=1503.11f;       //Monthly Payment $'s
    }
    nMonths=360;                   //Number of months in loan payment
    
    //Process or map the inputs to the outputs
    cout<<fixed<<setprecision(2)<<showpoint;
    cout<<"Home Amortization Table"<<endl<<endl;;
    cout<<"Purchase Price = $"<<pPrice<<endl;
    cout<<"Percent Down   =      "<<pDown*CNVPRCT<<"%"<<endl;
    cout<<"Loan Amount    =  "<<loanAmt[0]<<endl;
    cout<<"Interest Rate  =       "<<intRate*CNVPRCT<<"%"<<endl;
    cout<<"Monthly Payment= $  "<<mnPmt[0]<<endl<<endl;
    cout<<"Month     Loan Amount  Int Paid   Payment"<<endl;
    for(int month=0;month<nMonths;month++){
        intAccm[month]=intRate/CNVMNYR*loanAmt[month];//Interest Accrued per month
        cout<<setw(4)<<month<<setw(16)<<loanAmt[month]<<setw(10)<<intAccm[month]
                <<setw(11)<<mnPmt[month]<<endl;
        loanAmt[month+1]=(loanAmt[month]+intAccm[month]-mnPmt[month]);
    }
    cout<<endl;
    cout<<"Last Payment = $"<<mnPmt[360]+loanAmt[360]<<endl;
    cout<<"Total Paid for Loan = $"<<nMonths*mnPmt[360]+loanAmt[360]<<endl;
    cout<<"Total Paid for Home = $"<<pPrice*pDown+nMonths*mnPmt[360]+loanAmt[360]<<endl;
    
    //Exit the program
    return 0;
}