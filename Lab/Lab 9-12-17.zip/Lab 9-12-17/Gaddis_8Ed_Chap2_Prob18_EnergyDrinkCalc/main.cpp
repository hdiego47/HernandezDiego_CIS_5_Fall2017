/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on September 12, 2017, 12:05 PM
 * Purpose: Energy Drink Calculation
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    unsigned short nCustS=16500; //Number of People Surveyed
    float prcDrnk=.15f;          //Percent of surveyed that drink 1 or more Energy Drink/week
    float prfrCit=.58f;          //Percent of surveyed that prefer citrus flavor
    unsigned short nDrnkrs;      //Number of energy drink drinkers
    unsigned short nPrfCit;      //Number of drinkers that prefer Citrus flavor  
    
    //Process or map the inputs to the outputs
    nDrnkrs=nCustS*prcDrnk;  //Find the number of drinkers
    nPrfCit=nDrnkrs*prfrCit; //Find the number that prefer citrus
    
    //Display/Output all pertinent variables
    cout<<"The total amount of people surveyed is             "<<nCustS<<endl;
    cout<<"The percent of people that drink Energy Drinks is  "<<prcDrnk*100
            <<"%"<<endl;
    cout<<"The percent of people that prefer citrus is        "<<prfrCit*100
            <<"%"<<endl<<endl;
    cout<<"The number of people that drink Energy Drinks is   "<<nDrnkrs<<endl;
    cout<<"The number of people that prefer citrus is         "<<nPrfCit<<endl;
    
    //Exit the program
    return 0;
}