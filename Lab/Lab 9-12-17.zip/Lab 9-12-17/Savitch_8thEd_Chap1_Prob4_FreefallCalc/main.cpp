/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on September 12, 2017, 12:01 PM
 * Purpose: Creating our class template
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants
const float GRAVITY=32.174f; //Gravity ft/sec^2 @ sea level
const float CNVFTMT=3.28f;   //Conversion from feet to meters

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float time;   //time falling
    float distFt; //Distance object fell in ft
    float distMt; //Distance object fell in meters
    float gravMt; //Gravity constant in meters/sec^2
    
    //Input Data/Variables
    cout<<"This program calculates the distance dropped in free fall"<<endl;
    cout<<"Input the time in seconds during free fall"<<endl;
    cin>>time;
    
    //Process or map the inputs to the outputs
    distFt=.5*GRAVITY*time*time;
    distMt=distFt/CNVFTMT;
    gravMt=GRAVITY/CNVFTMT;
    
    //Display/Output all pertinent variables
    cout<<"The distance dropped in a free fall is  "<<distFt<<" feet"<<endl;
    cout<<"The distance dropped in meters is       "<<distMt<<" meters"<<endl;
    cout<<"The gravity constant in meters/sec^2 is "<<gravMt<<" m/sec^2"<<endl;
    
    //Exit the program
    return 0;
}