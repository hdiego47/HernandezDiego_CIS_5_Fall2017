/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on September 28, 2017, 11:54 AM
 * Purpose: Grading Assignments
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    signed short score;  //Score for assignment 0 to 100
    char grade;          //Letter grade assignment receives
    
    //Initialize Variables with an input
    cout<<"Input the score from the assignment"<<endl;
    cout<<"A value from 1 to 100"<<endl;
    cin>>score;
    
    //Process by giving and displaying the grade
    if(score>100){
        cout<<"A score of "<<score<< " gets a(n) "<<"I"<<endl;
    }else if(score>=90&&score<=100){
        cout<<"A score of "<<score<< " gets a(n) "<<"A"<<endl;
    }else if(score>=80&&score<90){
        cout<<"A score of "<<score<< " gets a(n) "<<"B"<<endl;
    }else if(score>=70&&score<80){
        cout<<"A score of "<<score<< " gets a(n) "<<"C"<<endl;
    }else if(score>=60&&score<70){
        cout<<"A score of "<<score<< " gets a(n) "<<"D"<<endl;
    }else if(score>=0&&score<=59){
        cout<<"A score of "<<score<< " gets a(n) "<<"F"<<endl;
    }else cout<<"A score of "<<score<< " gets a(n) "<<"I"<<endl;
    
    //Exit the program
    return 0;
}