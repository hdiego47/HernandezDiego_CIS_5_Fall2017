/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on October 5, 2017, 12:01 PM
 * Purpose: Soylent Green
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
#include <iomanip>   //Format library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    int fi,fim1,fim2,counter;
    int wtCrud=10;//5 lbs of crud to start
    int deltDys=5;//5 Days between increments
    
    //Initialize Variables
    fim1=fim2=1;
    counter=1;
    
    //Table Header
    cout<<"  Sequence   Crud Wt    N Days"<<endl;
    
    //Process or map the inputs to the outputs
    //First row
    cout<<setw(10)<<fim2<<setw(10)<<wtCrud*fim2
            <<setw(10)<<(counter-1)*deltDys<<endl;
    counter+=1;
    
    //second row
    cout<<setw(10)<<fim1<<setw(10)<<wtCrud*fim1
            <<setw(10)<<(counter-1)*deltDys<<endl;
    counter+=1;
    
    //Third row
    fi=fim1+fim2;
    cout<<setw(10)<<fi<<setw(10)<<wtCrud*fi
            <<setw(10)<<(counter-1)*deltDys<<endl;
    counter+=1;

    //fourth row
    int count;
    for(count=4;count<=17;count++){
    fim2=fim1;
    fim1=fi;
    fi=fim1+fim2;
    cout<<setw(10)<<fi<<setw(10)<<wtCrud*fi
            <<setw(10)<<(count-1)*deltDys<<endl;
    }
   
    //Exit the program
    return 0;
}