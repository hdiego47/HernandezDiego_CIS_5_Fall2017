/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on November 16, 2017, 11:22 AM
 * Purpose: Vehicle Calculator Version 1
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
#include <iomanip>   //Format Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants
const int CNVMNYR=12; //Conversion Months to Year
const int CNVPRCT=100;//Conversion to percent

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float pPrice,pDown,loanAmt,intRate,mnPmt;
    int nMonths;
    
    //Initialize Variables
    pPrice=10000.00f;        //Purchase Price = $10k
    pDown=0.0f;              //0%
    loanAmt=pPrice*(1-pDown);//Loan Amount $'s
    intRate=0.05;            //Interest Rate/year
    mnPmt=299.71f;           //Monthly Payment $'s
    nMonths=36;              //Number of months in loan payment
    
    //Process or map the inputs to the outputs
    cout<<fixed<<setprecision(2)<<showpoint;
    cout<<"Vehicle Payment Table"<<endl<<endl;;
    cout<<"Purchase Price = $"<<pPrice<<endl;
    cout<<"Percent Down   =      "<<pDown*CNVPRCT<<"%"<<endl;
    cout<<"Loan Amount    =  "<<loanAmt<<endl;
    cout<<"Interest Rate  =      "<<intRate*CNVPRCT<<"%"<<endl;
    cout<<"Monthly Payment= $  "<<mnPmt<<endl<<endl;
    cout<<"Month     Loan Amount  Int Paid   Payment"<<endl;
    for(int month=0;month<nMonths;month++){
        float intAccm=intRate/CNVMNYR*loanAmt;//Interest Accrued per month
        cout<<setw(4)<<month<<setw(16)<<loanAmt<<setw(10)<<intAccm
                <<setw(11)<<mnPmt<<endl;
        loanAmt+=(intAccm-mnPmt);
    }
    cout<<endl;
    cout<<"Last Payment = $"<<mnPmt+loanAmt<<endl;
    cout<<"Total Paid for Loan    = $"<<nMonths*mnPmt+loanAmt<<endl;
    cout<<"Total Paid for Vehicle = $"<<pPrice*pDown+nMonths*mnPmt+loanAmt<<endl;
    
    //Exit the program
    return 0;
}