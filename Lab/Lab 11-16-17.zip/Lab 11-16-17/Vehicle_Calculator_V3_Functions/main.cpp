/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on November 16, 2017, 11:45 AM
 * Purpose: Vehicle Calculator Version 2 with Arrays
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
#include <iomanip>   //Format Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants
const int CNVMNYR=12; //Conversion Months to Year
const int CNVPRCT=100;//Conversion to percent

//Function Prototypes
void display(float,float,float,float,float[],float[],int,int);
void calc(float[],float[],float,float,int,int);

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    const int SIZE=36;
    float pPrice,pDown,loanAmt[SIZE]={},intRate,mnPmt,intAccm[SIZE]={};
    int nMonths;
    
    //Initialize Variables
    pPrice=10000.00f;        //Purchase Price = $10k
    pDown=0.0f;              //0%
    loanAmt[0]=pPrice*(1-pDown);//Loan Amount $'s
    intRate=0.05;            //Interest Rate/year
    mnPmt=299.71f;           //Monthly Payment $'s
    nMonths=36;              //Number of months in loan payment
    
    //Process or map the inputs to the outputs
    calc(intAccm,loanAmt,intRate,mnPmt,nMonths,SIZE);
    
    //Display the Table
    display(pPrice,pDown,intRate,mnPmt,loanAmt,intAccm,nMonths,SIZE);
    
    //Exit the program
    return 0;
}

void display(float pPrice,float pDown,float intRate,float mnPmt,float loanAmt[],
    float intAccm[],int nMonths,int SIZE){
    cout<<fixed<<setprecision(2)<<showpoint;
    cout<<"Vehicle Payment Table"<<endl<<endl;;
    cout<<"Purchase Price = $"<<pPrice<<endl;
    cout<<"Percent Down   =      "<<pDown*CNVPRCT<<"%"<<endl;
    cout<<"Loan Amount    =  "<<loanAmt[0]<<endl;
    cout<<"Interest Rate  =      "<<intRate*CNVPRCT<<"%"<<endl;
    cout<<"Monthly Payment= $  "<<mnPmt<<endl<<endl;
    cout<<"Month     Loan Amount  Int Paid   Payment"<<endl;
    for(int month=0;month<nMonths;month++){
        cout<<setw(4)<<month<<setw(16)<<loanAmt[month]<<setw(10)<<intAccm[month]
                <<setw(11)<<mnPmt<<endl;
    }
    cout<<endl;
    cout<<"Last Payment = $"<<mnPmt+loanAmt[36]<<endl;
    cout<<"Total Paid for Loan    = $"<<nMonths*mnPmt+loanAmt[36]<<endl;
    cout<<"Total Paid for Vehicle = $"<<pPrice*pDown+nMonths*mnPmt+loanAmt[36]<<endl;
    
}

void calc(float intAccm[],float loanAmt[],float intRate,float mnPmt,
    int nMonths,int SIZE){
    for(int month=0;month<nMonths;month++){
        intAccm[month]=intRate/CNVMNYR*loanAmt[month];//Interest Accrued per month
        loanAmt[month+1]=(loanAmt[month]+intAccm[month]-mnPmt);
    }
}