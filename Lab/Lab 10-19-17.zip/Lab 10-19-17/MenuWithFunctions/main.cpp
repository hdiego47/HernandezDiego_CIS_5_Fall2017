/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on October 5, 2017, 11:30 AM
 * Purpose: Creating our class template
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes
void menu();
void prob1();
void prob2();
void prob3();
void prob4();
void prob5();
void prob6();
void prob7();
void prob8();
void prob9();


//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    int choice;
    
    //Input Data/Variables
    menu();
    do{
        cin>>choice;
        cout<<endl;

        //Process or map the inputs to the outputs
        switch(choice){
            case 1:prob1();break;
            case 2:prob2();break;
            case 3:prob3();break;
            case 4:prob4();break;
            case 5:prob5();break;
            case 6:prob6();break;
            case 7:prob7();break;
            case 8:prob8();break;
            case 9:prob9();break;
            default: cout<<"The program has ended"<<endl;
        }
    }while(choice>=1&&choice<=9);

    //Exit the program
    return 0;
}

void prob1(){
    cout<<"Problem 1"<<endl<<endl;
}

void prob2(){
    cout<<"Problem 2"<<endl<<endl;
}

void prob3(){
    cout<<"Problem 3"<<endl<<endl;
}

void prob4(){
    cout<<"Problem 4"<<endl<<endl;
}

void prob5(){
    cout<<"Problem 5"<<endl<<endl;
}

void prob6(){
    cout<<"Problem 6"<<endl<<endl;
}

void prob7(){
    cout<<"Problem 7"<<endl<<endl;
}

void prob8(){
    cout<<"Problem 8"<<endl<<endl;
}

void prob9(){
    cout<<"Problem 9"<<endl<<endl;
}

void menu(){
    cout<<"Please choose the problem you wish to run"<<endl;
        cout<<"Enter any other number to end the program"<<endl;
        cout<<"1. "<<endl;
        cout<<"2. "<<endl;
        cout<<"3. "<<endl;
        cout<<"4. "<<endl;
        cout<<"5. "<<endl;
        cout<<"6. "<<endl;
        cout<<"7. "<<endl;
        cout<<"8. "<<endl;
        cout<<"9. "<<endl;
}