/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on October 19, 2017, 7:38 PM
 * Purpose: To find how many calories are burned on a treadmill
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float calBrn=3.6f; //Calories burned per minute
    float mins=0;        //Number of minutes run
    float totCalB;     //Total Calories burned
    
    //Process or map the inputs to the outputs
    cout<<"Minutes      Calories Burned"<<endl;
    for(int cnt=1;cnt<=6;cnt++){
        mins+=5;
        totCalB=mins*calBrn;
        cout<<mins<<"                 "<<totCalB<<endl;
    }

    //Exit the program
    return 0;
}