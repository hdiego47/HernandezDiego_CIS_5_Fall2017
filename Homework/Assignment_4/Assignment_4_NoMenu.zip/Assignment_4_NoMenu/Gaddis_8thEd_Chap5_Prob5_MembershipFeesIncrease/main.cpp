/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on October 19, 2017, 7:57 PM
 * Purpose: To calculate the membership increase of a country club
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
#include <iomanip>   //Format library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float charge=2500; //The amount the club charges
    float prcIncr=.04f;//The percent increase in the membership fee
    float incrse=0;    //The amount it will increase by
    short year=0;      //The number of years
    
    //Process or map the inputs to the outputs
    cout<<"Year      Fee"<<endl;
    cout<<fixed<<setprecision(2)<<showpoint;
    cout<<" "<<year<<"        $"<<charge<<endl;
    year++;
    for(int cnt=1;cnt<=6;cnt++){
        incrse=charge*prcIncr;
        charge+=incrse;
        cout<<" "<<year<<"        $"<<charge<<endl;
        year++;
    }
    
    //Display/Output all pertinent variables
    
    //Exit the program
    return 0;
}