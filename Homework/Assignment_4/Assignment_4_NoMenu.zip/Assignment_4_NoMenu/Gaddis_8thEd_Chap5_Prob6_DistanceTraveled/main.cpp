/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on September 20, 2017, 9:43 PM
 * Purpose: Creating our class template
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    int dist;   //The distance the vehicle has traveled in miles
    int time;   //The time (hours) it took for the vehicle to travel
    int speed;  //The speed the vehicle was moving in m/h
    
    //Input Data/Variables
    do{
    cout<<"This program calculates the distance a vehicle traveled"<<endl;
    cout<<"Please enter the speed in miles per hour and time in hours"<<endl;
    cin>>speed>>time;
    cout<<endl;
    }while(speed<0||time<1);
    //Process or map the inputs to the outputs
    cout<<"Hour   Distance Traveled"<<endl;
    for(int cnt=1;cnt<=time;cnt++){
        dist=speed*cnt;
        cout<<" "<<cnt<<"         "<<dist<<" Miles"<<endl;
    }
    
    //Display/Output all pertinent variables
    
    //Exit the program
    return 0;
}