/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on October 19, 2017, 6:43 PM
 * Purpose: To predict the ocean levels
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
#include <iomanip>   //Format Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    int year=2017;     //The year to start from
    float mmRise=1.5f; //How much the ocean is rising each year in millimeters
    float totRise;     //Total amount risen
    
    //Process or map the inputs to the outputs
    cout<<"This program predicts the amount the ocean will rise in the next"<<
            " 25 years"<<endl<<endl;
    cout<<"Year       Amount Risen"<<endl;
    cout<<fixed<<setprecision(1)<<showpoint;
    for(int cnt=0;cnt<=25;cnt++){
        cout<<year<<"         "<<totRise<<" mm"<<endl;
        year++;
        totRise+=mmRise;
    }
    
    //Display/Output all pertinent variables
    
    //Exit the program
    return 0;
}