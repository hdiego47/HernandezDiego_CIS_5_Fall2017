/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on October 19, 2017, 6:02 PM
 * Purpose: To find the sum of numbers
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    int num;  //The number the user enters
    int sum;  //The sum of the numbers
    
    //Input Data/Variables
    do{
    cout<<"This program finds the sum of all the numbers up to the number inputed"<<endl;
    cout<<"Please input a positive integer"<<endl;
    cin>>num;
    cout<<endl;
    }while(num<0);
    
    //Process or map the inputs to the outputs
    for(int cnt=1;cnt<=num;cnt++){
        sum+=cnt;
    }
    
    //Display/Output all pertinent variables
    cout<<"The number inputed was                    "<<num<<endl;
    cout<<"The sum of the numbers up to the input is "<<sum<<endl;
    
    //Exit the program
    return 0;
}