/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on October 19, 2017, 9:13 PM
 * Purpose: Assignment 4 menu
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
#include <fstream>   //file library
#include <cmath>     //Math Library
#include <iomanip>   //Format Library
#include <cstring>   //String Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants
const float GRAVITY=6.673e-8f; //Universal gravitational constant
const float CNVCMFT=1/30.48f;  //30.48cm/ft
const float CNVMIFT=5280.0f;   //5280ft/mile
const float CNVGKG=1000.0f;    //100 grams to 1 kilogram
const float REARTH=3959.0f;    //Radius of the earth
const float MEARTH=5.972e24f;  //Mass of the earth

//Function Prototypes
void menu();
void prob1();
void prob2();
void prob3();
void prob4();
void prob5();
void prob6();
void prob7();
void prob8();
void prob9();


//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    int choice;
    
    //Input Data/Variables
    menu();
    do{
        cin>>choice;
        cout<<endl;

        //Process or map the inputs to the outputs
        switch(choice){
            case 1:prob1();break;
            case 2:prob2();break;
            case 3:prob3();break;
            case 4:prob4();break;
            case 5:prob5();break;
            case 6:prob6();break;
            case 7:prob7();break;
            case 8:prob8();break;
            case 9:prob9();break;
            default: cout<<"The program has ended"<<endl;
        }
    }while(choice>=1&&choice<=9);

    //Exit the program
    return 0;
}

void prob1(){
    //Declare Variables
    int num;  //The number the user enters
    int sum;  //The sum of the numbers
    
    //Input Data/Variables
    do{
    cout<<"This program finds the sum of all the numbers up to the number inputed"<<endl;
    cout<<"Please input a positive integer"<<endl;
    cin>>num;
    cout<<endl;
    }while(num<0);
    
    //Process or map the inputs to the outputs
    for(int cnt=1;cnt<=num;cnt++){
        sum+=cnt;
    }
    
    //Display/Output all pertinent variables
    cout<<"The number inputed was                    "<<num<<endl;
    cout<<"The sum of the numbers up to the input is "<<sum<<endl;
    
}

void prob2(){
    //Declare Variables
    int year=2017;     //The year to start from
    float mmRise=1.5f; //How much the ocean is rising each year in millimeters
    float totRise;     //Total amount risen
    
    //Process or map the inputs to the outputs
    cout<<"This program predicts the amount the ocean will rise in the next"<<
            " 25 years"<<endl<<endl;
    cout<<"Year       Amount Risen"<<endl;
    cout<<fixed<<setprecision(1)<<showpoint;
    for(int cnt=0;cnt<=25;cnt++){
        cout<<year<<"         "<<totRise<<" mm"<<endl;
        year++;
        totRise+=mmRise;
    }
    
}

void prob3(){
    //Declare Variables
    float calBrn=3.6f; //Calories burned per minute
    float mins=0;        //Number of minutes run
    float totCalB;     //Total Calories burned
    
    //Process or map the inputs to the outputs
    cout<<"Minutes      Calories Burned"<<endl;
    for(int cnt=1;cnt<=6;cnt++){
        mins+=5;
        totCalB=mins*calBrn;
        cout<<mins<<"                 "<<totCalB<<endl;
    }

}

void prob4(){
     //Declare Variables
    float charge=2500; //The amount the club charges
    float prcIncr=.04f;//The percent increase in the membership fee
    float incrse=0;    //The amount it will increase by
    short year=0;      //The number of years
    
    //Process or map the inputs to the outputs
    cout<<"Year      Fee"<<endl;
    cout<<fixed<<setprecision(2)<<showpoint;
    cout<<" "<<year<<"        $"<<charge<<endl;
    year++;
    for(int cnt=1;cnt<=6;cnt++){
        incrse=charge*prcIncr;
        charge+=incrse;
        cout<<" "<<year<<"        $"<<charge<<endl;
        year++;
    }
    
}

void prob5(){
    //Declare Variables
    int dist;   //The distance the vehicle has traveled in miles
    int time;   //The time (hours) it took for the vehicle to travel
    int speed;  //The speed the vehicle was moving in m/h
    
    //Input Data/Variables
    do{
    cout<<"This program calculates the distance a vehicle traveled"<<endl;
    cout<<"Please enter the speed in miles per hour and time in hours"<<endl;
    cin>>speed>>time;
    cout<<endl;
    }while(speed<0||time<1);
    //Process or map the inputs to the outputs
    cout<<"Hour   Distance Traveled"<<endl;
    for(int cnt=1;cnt<=time;cnt++){
        dist=speed*cnt;
        cout<<" "<<cnt<<"         "<<dist<<" Miles"<<endl;
    }
    
}

void prob6(){
    //Display/Output all pertinent variables
    for(int cnt1=1,cnt2=19,cnt3=10;cnt1<=10;cnt1++,cnt2--,cnt3--){
        //Display First Triangle
        for(int t1=1;t1<=cnt1;t1++)cout<<"*";
        //Display Middle Spaces
        for(int t1=1;t1<=cnt2;t1++)cout<<" ";
        //Display Second Triangle
        for(int t1=1;t1<=cnt3;t1++)cout<<"*";
        cout<<endl;
    }
    
}

void prob7(){
    //Declare Variables
    string fName,usrName,usrBio;
    ofstream out;
    
    //Initialize Variables
    fName="webpage.html";
    out.open(fName.c_str());
    
    //Input Data/Variables
    cout<<"Generate Code for a Bio Webpage"<<endl;
    cout<<"Input Name"<<endl;
    getline(cin,usrName);
    cout<<"Input Bio"<<endl;
    getline(cin,usrBio);
    
    //Generate the Web Page
    cout<<"<html>"<<endl;
    cout<<" <head>"<<endl;
    cout<<"     <title>Gaddis 9thEd Chap5 Prob26 Web Page Generator</title>"<<endl;
    cout<<" <head>"<<endl;
    cout<<" <body>"<<endl;
    cout<<"     <center>"<<endl;
    cout<<"         <h1>"<<usrName<<"</h1>"<<endl;
    cout<<"         <hr />"<<endl;
    cout<<"             "<<usrBio<<endl;
    cout<<"         <hr />"<<endl;
    cout<<"     <center>"<<endl;
    cout<<" </body>"<<endl;
    cout<<"</html>"<<endl;
    
    out<<"<html>"<<endl;
    out<<" <head>"<<endl;
    out<<"     <title>Gaddis 9thEd Chap5 Prob26 Web Page Generator</title>"<<endl;
    out<<" <head>"<<endl;
    out<<" <body>"<<endl;
    out<<"     <center>"<<endl;
    out<<"         <h1>"<<usrName<<"</h1>"<<endl;
    out<<"         <hr />"<<endl;
    out<<"             "<<usrBio<<endl;
    out<<"         <hr />"<<endl;
    out<<"     <center>"<<endl;
    out<<" </body>"<<endl;
    out<<"</html>"<<endl;
    
    //Close file
    out.close();
    
    
}

void prob8(){
     //Declare Variables
    int yrNow=2017,yrThen;
    float infRate,prNow,prThen;
    
    //Initialize Variables
    
    //Input Data/Variables
    cout<<"This program calculates inflation rate"<<endl;
    cout<<"Input the Year and Price of Original item"<<endl;
    cout<<"as well as Price today"<<endl;
    cin>>yrThen>>prThen>>prNow;
    cout<<endl;
    
    //Process or map the inputs to the outputs
    infRate=.09;
    float delta,tol=.001,prCalc;
    float kGain=.001;
    do{
        prCalc=prThen;
        for(int year=yrThen+1;year<=yrNow;year++){
            prCalc*=(1+infRate);
        }
        delta=prNow-prCalc;
        infRate+=kGain*delta;
    }while(abs(delta)>=tol);
    
    //Display/Output all pertinent variables
    cout<<fixed<<setprecision(2)<<showpoint;
    cout<<"In "<<yrThen<<" The price = $"<<prThen<<endl;
    cout<<"In "<<yrNow<<" The price  = $"<<prNow<<endl;
    cout<<"The Price calculated = $"<<prCalc<<endl;
    cout<<"The inflation rate   = "<<infRate*100.0f<<"%"<<endl;
    
}

void prob9(){
    //Declare Variables
    float myMass, myWgt;  //The users mass and weight
    float actWgt;
    
    //Initialize Variables
    myMass=6.0f;
    
    //Input Data/Variables
    cout<<"This program converts your weight in lbs to"<<endl;
    cout<<"Your mass in slugs"<<endl;
    cout<<"Input your actual weight in lbs"<<endl;
    cin>>actWgt;
    cout<<endl;
    
    //Process or map the inputs to the outputs
    float delta,tol=.001f;
    float kGain=tol;
    do{
        myWgt=GRAVITY*pow(CNVCMFT,3)*MEARTH*CNVGKG*myMass/
                (pow(REARTH,2)*pow(CNVMIFT,2));
        delta=actWgt-myWgt;
        myMass+=kGain*delta;
    }while(abs(delta)>=tol);
    
    //Display/Output all pertinent variables
    cout<<"Your weight = "<<myWgt<<" lbs"<<endl;
    cout<<"Your mass   = "<<myMass<<" slugs"<<endl;
    
}

void menu(){
    cout<<"Please choose the problem you wish to run"<<endl;
        cout<<"Enter any other number to end the program"<<endl;
        cout<<"1. Gaddis_8thEd_Chap5_Prob1_SumofNumbers"<<endl;
        cout<<"2. Gaddis_8thEd_Chap5_Prob3_OceanLevels"<<endl;
        cout<<"3. Gaddis_8thEd_Chap5_Prob4_CaloriesBurned"<<endl;
        cout<<"4. Gaddis_8thEd_Chap5_Prob5_MembershipFeesIncrease"<<endl;
        cout<<"5. Gaddis_8thEd_Chap5_Prob6_DistanceTraveled"<<endl;
        cout<<"6. Gaddis_8thEd_Chap5_Prob23_PatternDisplay"<<endl;
        cout<<"7. Gaddis_9thEd_Chap5_Prob26_WebPage"<<endl;
        cout<<"8. Savich_8thEd_Chap4_Prob4_Inflation"<<endl;
        cout<<"9. Savich_8thEd_Chap4_Prob7_Weight"<<endl;
}