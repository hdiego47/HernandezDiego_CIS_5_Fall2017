/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on October 5, 2017, 11:30 AM
 * Purpose: Creating our class template
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
#include <cmath>     //Math library
#include <iomanip>   //Format library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants
const float PI=3.14159f;

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    int choice;
    
    //Input Data/Variables
    cout<<"Please choose the problem you want to run"<<endl;
    cout<<"1. Gaddis_8thEd_Chap4_Prob1_MinimumMaximum"<<endl;
    cout<<"2. Gaddis_8thEd_Chap4_Prob2_RomanNumerals"<<endl;
    cout<<"3. Gaddis_8thEd_Chap4_Prob3_MagicDates"<<endl;
    cout<<"4. Gaddis_8thEd_Chap4_Prob4_AreasofRectangles"<<endl;
    cout<<"5. Gaddis_8thEd_Chap4_Prob5_BMI"<<endl;
    cout<<"6. Gaddis_8thEd_Chap4_Prob6_MassandWeight"<<endl;
    cout<<"7. Gaddis_8thEd_Chap4_Prob10_DaysInAMonth"<<endl;
    cout<<"8. Gaddis_8thEd_Chap4_Prob21_TheSpeedofSound"<<endl;
    cout<<"9. Gaddis_8thEd_Chap4_Prob23_GeometryCalculator"<<endl;
    cout<<"10.Savitch_9thEd_Chap3_Prob6_SoylentGreen"<<endl;
    cin>>choice;
    
    //Process or map the inputs to the outputs
    switch(choice){
        case 1:{
            //Declare Variables
        int num1,num2;  //The two numbers to be entered
        int big,small; //The bigger and smaller numbers

        //Input Data/Variables
        cout<<"This program determines which number is larger and which is smaller"<<endl;
        cout<<"Please enter two numbers"<<endl;
        cin>>num1>>num2;
        cout<<endl;

        //Process or map the inputs to the outputs
        big=num1>num2?num1:num2;
        small=num1<num2?num1:num2;

        //Display/Output all pertinent variables
        cout<<"The two numbers entered were "<<num1<<" and "<<num2<<endl;
        cout<<"The bigger number was  "<<big<<endl;
        cout<<"The smaller number was "<<small<<endl;
            
        }break;

        case 2:{
            //Declare Variables
        short num; //Number to be converted to Roman Numeral

        //Input Data/Variables
        cout<<"This program converts numbers 1 to 10 to Roman Numerals"<<endl;
        cout<<"Please enter a number from 1 to 10"<<endl;
        cin>>num;
        cout<<endl;

        //Process or map the inputs to the outputs
        switch(num){

            case  1: cout<<"The Roman Numeral for 1 is i"<<endl;break;

            case  2: cout<<"The Roman Numeral for 2 is ii"<<endl;break;

            case  3: cout<<"The Roman Numeral for 3 is iii"<<endl;break;

            case  4: cout<<"The Roman Numeral for 4 is iv"<<endl;break;

            case  5: cout<<"The Roman Numeral for 5 is v"<<endl;break;

            case  6: cout<<"The Roman Numeral for 6 is vi"<<endl;break;

            case  7: cout<<"The Roman Numeral for 7 is vii"<<endl;break;

            case  8: cout<<"The Roman Numeral for 8 is viii"<<endl;break;

            case  9: cout<<"The Roman Numeral for 9 is ix"<<endl;break;

            case 10: cout<<"The Roman Numeral for 10 is x"<<endl;break;

            default: cout<<"Invalid input"<<endl;
        }
            
        }break;

        case 3:{
        //Declare Variables
        short month,day,year;  //The date to be inputed

        //Input Data/Variables
        cout<<"Please enter a month (in numeric form),day,and two digit year"<<endl;
        cin>>month>>day>>year;
        cout<<endl;

        //Process or map the inputs to the outputs
        if(month*day==year)cout<<"The date is magic!"<<endl;
        else cout<<"The date is not magic..."<<endl;
            
        }break;

        case 4:{
            //Declare Variables
        int lngth1,lngth2;  //the length of the two rectangles
        int wdth1,wdth2;    //The width of the two rectangles
        int area1,area2;    //The area of the two rectangles
        int big,small;      //The larger area and the smaller area

        //Input Data/Variables
        cout<<"This program finds which rectangle's area is bigger or if they are equal"<<endl;
        cout<<"Please enter the length then the width of the first rectangle in feet"<<endl;
        cin>>lngth1>>wdth1;
        cout<<"Now enter the length then the width of the second rectangle in feet"<<endl;
        cin>>lngth2>>wdth2;

        //Process or map the inputs to the outputs and display the data
        area1=lngth1*wdth1;
        area2=lngth2*wdth2;
        if(area1>area2){
            cout<<"Rectangle 1's area is "<<area1<<" ft^2"<<endl;
            cout<<"Rectangle 2's area is "<<area2<<" ft^2"<<endl;
            cout<<"Rectangle 1's area is larger than Rectangle 2's area"<<endl;
        }else if(area2>area1){
            cout<<"Rectangle 1's area is "<<area1<<" ft^2"<<endl;
            cout<<"Rectangle 2's area is "<<area2<<" ft^2"<<endl;
            cout<<"Rectangle 2's area is larger than Rectangle 1's area"<<endl;
        }else{ 
            cout<<"Rectangle 1's area is "<<area1<<" ft^2"<<endl;
            cout<<"Rectangle 2's area is "<<area2<<" ft^2"<<endl;
            cout<<"The area of both rectangles is equal"<<endl;
        }
            
        }break;

        case 5:{
        //Declare Variables
        float wt,ht,bmi;  //The person's weight height and BMI

        //Input Data/Variables
        cout<<"This program tells you if you are healthy using your BMI"<<endl;
        cout<<"Please enter your weight pounds then your height in inches"<<endl;
        cin>>wt>>ht;

        //Process or map the inputs to the outputs
        bmi=wt*703/pow(ht,2);
        cout<<fixed<<setprecision(1)<<showpoint;
        if(bmi<18.5){
            cout<<"Your BMI is "<<bmi<<endl;
            cout<<"According to your BMI you are underweight"<<endl;
        }else if(bmi>=18.5&&bmi<=25){
            cout<<"Your BMI is "<<bmi<<endl;
            cout<<"According to your BMI you have optimal weight"<<endl;
        }else{
            cout<<"Your BMI is "<<bmi<<endl;
            cout<<"According to your BMI you are overweight"<<endl;
        }
            
        }break;

        case 6:{
        //Declare Variables
        float mass;
        float weight;
        float grav=9.8f;

        //Input Data/Variables
        cout<<"This program calculates the weight of an object"<<endl;
        cout<<"Enter the mass of the object"<<endl;
        cin>>mass;
        cout<<endl;

        //Process or map the inputs to the outputs
        weight=mass*grav;
        cout<<"The mass of the object is "<<weight<<endl;
        if(weight>1000)cout<<"The object is too heavy"<<endl;
        if(weight<10)cout<<"The object is too light"<<endl;
            
        }break;

        case 7:{
        //Declare Variables
        int month,year;

        //Input Data/Variables
        cout<<"This program tells you how many days are in a month"<<endl;
        cout<<"Please enter a month then a year"<<endl;
        cin>>month>>year;

        //Process or map the inputs to the outputs
        if(month==1)cout<<"January has 31 days"<<endl;
        if(month==2){
            if(year%100==0&&year%400==0)cout<<"February has 29 days"<<endl;
            else if(year%100!=0&&year%4==0)cout<<"February has 29 days"<<endl;
            else cout<<"February has 28 days"<<endl;
        }
        if(month==3)cout<<"March has 31 days"<<endl;
        if(month==4)cout<<"April has 30 days"<<endl;
        if(month==5)cout<<"May has 31 days"<<endl;
        if(month==6)cout<<"June has 30 days"<<endl;
        if(month==7)cout<<"July has 31 days"<<endl;
        if(month==8)cout<<"August has 31 days"<<endl;
        if(month==9)cout<<"September has 30 days"<<endl;
        if(month==10)cout<<"October has 31 days"<<endl;
        if(month==11)cout<<"November has 30 days"<<endl;
        if(month==12)cout<<"December has 31 days"<<endl;
            
        }break;

        case 8:{
            //Declare Variables
        short menu;

        //Input Data/Variables
        cout<<"Choose the medium"<<endl;
        cout<<"1. Carbon Dioxide"<<endl;
        cout<<"2. Air"<<endl;
        cout<<"3. Helium"<<endl;
        cout<<"4. Hydrogen"<<endl;
        cin>>menu;
        cout<<endl;

        //Process or map the inputs to the outputs
        switch(menu){
            case 1:{
                float time;
                float speed=258.0f;
                float dist;
                cout<<"Enter the number of seconds it took for the sound to move"<<endl;
                cin>>time;
                if(time<0||time>30){cout<<"Time can not be greater than 30 seconds";
                cout<<"or less than 0 seconds"<<endl;
                }
                else {dist=time*speed;
                cout<<"The source of the sound was "<<dist<<" meters away"<<endl;
                }
            }break;

            case 2:{
                float time;
                float speed=331.5f;
                float dist;
                cout<<"Enter the number of seconds it took for the sound to move"<<endl;
                cin>>time;
                if(time<0||time>30){cout<<"Time can not be greater than 30 seconds";
                cout<<"or less than 0 seconds"<<endl;
                }
                else {dist=time*speed;
                cout<<"The source of the sound was "<<dist<<" meters away"<<endl;
                }
            }break;

            case 3:{
                float time;
                float speed=972.0f;
                float dist;
                cout<<"Enter the number of seconds it took for the sound to move"<<endl;
                cin>>time;
                if(time<0||time>30){cout<<"Time can not be greater than 30 seconds";
                cout<<"or less than 0 seconds"<<endl;
                }
                else {dist=time*speed;
                cout<<"The source of the sound was "<<dist<<" meters away"<<endl;
                }
            }break;

            case 4:{
                float time;
                float speed=1270.0f;
                float dist;
                cout<<"Enter the number of seconds it took for the sound to move"<<endl;
                cin>>time;
                if(time<0||time>30){cout<<"Time can not be greater than 30 seconds";
                cout<<"or less than 0 seconds"<<endl;
                }
                else {dist=time*speed;
                cout<<"The source of the sound was "<<dist<<" meters away"<<endl;
                }
            }break;

            default: cout<<"Invalid choice"<<endl;
        }
            
        }break;

        case 9:{
        //Declare Variables
        short menu;

        //Input Data/Variables
        cout<<"Choose a program to run"<<endl;
        cout<<"1. Calculate the Area of a Circle"<<endl;
        cout<<"2. Calculate the Area of a Rectangle"<<endl;
        cout<<"3. Calculate the Area of a Triangle"<<endl;
        cout<<"4. Quit"<<endl;
        cin>>menu;
        cout<<endl;

        //The geometry calculator
        cout<<fixed<<setprecision(1)<<showpoint;
        switch(menu){
            case 1:{
                float rad;  //The radius of the circle
                float area; //The area of the circle
                cout<<"Enter the radius of the circle"<<endl;
                cout<<"Negative numbers are not valid"<<endl;
                cin>>rad;
                if(rad<0)cout<<"You entered an invalid number"<<endl;
                else{ area=PI*pow(rad,2);
                cout<<"The Area of the Circle is "<<area<<endl;
                }
            }break;

            case 2:{
                int lngth;
                int wdth;
                int area;
                cout<<"Enter the length then the width of the rectangle"<<endl;
                cout<<"Negative numbers are not valid"<<endl;
                cin>>lngth>>wdth;
                if(lngth<0||wdth<0)cout<<"You entered an invalid number"<<endl;
                else {area=lngth*wdth;
                cout<<"The area of the rectangle is "<<area<<endl;
                }
            }break;

            case 3:{
                float area;
                float base;
                float hight;
                cout<<"Enter the base then the hight of the triangle"<<endl;
                cout<<"Negative numbers are not valid"<<endl;
                cin>>base>>hight;
                if(base<0||hight<0)cout<<"You entered an invalid number"<<endl;
                else {area=.5*base*hight;
                cout<<"The area of the triangle is "<<area<<endl;
                }
            }break;

            case 4:{
                cout<<"The program has ended"<<endl;

            }break;
            default: cout<<"You have entered an invalid number"<<endl;
        }
            
        }break;
        
        case 10:{
            //Declare Variables
        int fi,fim1,fim2,counter;
        int wtCrud=10;//5 lbs of crud to start
        int deltDys=5;//5 Days between increments

        //Initialize Variables
        fim1=fim2=1;
        counter=1;

        //Table Header
        cout<<"  Sequence   Crud Wt    N Days"<<endl;

        //Process or map the inputs to the outputs
        //First row
        cout<<setw(10)<<fim2<<setw(10)<<wtCrud*fim2
                <<setw(10)<<(counter-1)*deltDys<<endl;
        counter+=1;

        //second row
        cout<<setw(10)<<fim1<<setw(10)<<wtCrud*fim1
                <<setw(10)<<(counter-1)*deltDys<<endl;
        counter+=1;

        //Third row
        fi=fim1+fim2;
        cout<<setw(10)<<fi<<setw(10)<<wtCrud*fi
                <<setw(10)<<(counter-1)*deltDys<<endl;
        counter+=1;

        //fourth row
        fim2=fim1;
        fim1=fi;
        fi=fim1+fim2;
        cout<<setw(10)<<fi<<setw(10)<<wtCrud*fi
                <<setw(10)<<(counter-1)*deltDys<<endl;
        counter+=1;

        //nth Row
        fim2=fim1;
        fim1=fi;
        fi=fim1+fim2;
        cout<<setw(10)<<fi<<setw(10)<<wtCrud*fi
                <<setw(10)<<(counter-1)*deltDys<<endl;
        counter+=1;

        fim2=fim1;
        fim1=fi;
        fi=fim1+fim2;
        cout<<setw(10)<<fi<<setw(10)<<wtCrud*fi
                <<setw(10)<<(counter-1)*deltDys<<endl;
        counter+=1;

        fim2=fim1;
        fim1=fi;
        fi=fim1+fim2;
        cout<<setw(10)<<fi<<setw(10)<<wtCrud*fi
                <<setw(10)<<(counter-1)*deltDys<<endl;
        counter+=1;

        fim2=fim1;
        fim1=fi;
        fi=fim1+fim2;
        cout<<setw(10)<<fi<<setw(10)<<wtCrud*fi
                <<setw(10)<<(counter-1)*deltDys<<endl;
        counter+=1;

        fim2=fim1;
        fim1=fi;
        fi=fim1+fim2;
        cout<<setw(10)<<fi<<setw(10)<<wtCrud*fi
                <<setw(10)<<(counter-1)*deltDys<<endl;
        counter+=1;

        fim2=fim1;
        fim1=fi;
        fi=fim1+fim2;
        cout<<setw(10)<<fi<<setw(10)<<wtCrud*fi
                <<setw(10)<<(counter-1)*deltDys<<endl;
        counter+=1;

        fim2=fim1;
        fim1=fi;
        fi=fim1+fim2;
        cout<<setw(10)<<fi<<setw(10)<<wtCrud*fi
                <<setw(10)<<(counter-1)*deltDys<<endl;
        counter+=1;

        fim2=fim1;
        fim1=fi;
        fi=fim1+fim2;
        cout<<setw(10)<<fi<<setw(10)<<wtCrud*fi
                <<setw(10)<<(counter-1)*deltDys<<endl;
        counter+=1;

        fim2=fim1;
        fim1=fi;
        fi=fim1+fim2;
        cout<<setw(10)<<fi<<setw(10)<<wtCrud*fi
                <<setw(10)<<(counter-1)*deltDys<<endl;
        counter+=1;

        fim2=fim1;
        fim1=fi;
        fi=fim1+fim2;
        cout<<setw(10)<<fi<<setw(10)<<wtCrud*fi
                <<setw(10)<<(counter-1)*deltDys<<endl;
        counter+=1;

        fim2=fim1;
        fim1=fi;
        fi=fim1+fim2;
        cout<<setw(10)<<fi<<setw(10)<<wtCrud*fi
                <<setw(10)<<(counter-1)*deltDys<<endl;
        counter+=1;

        fim2=fim1;
        fim1=fi;
        fi=fim1+fim2;
        cout<<setw(10)<<fi<<setw(10)<<wtCrud*fi
                <<setw(10)<<(counter-1)*deltDys<<endl;
        counter+=1;

        //Display/Output all pertinent variables

        //Exit the program
            
        }
        
        default:{ cout<<"Invalid input"<<endl;
        cout<<"Please run the program again and choose one of the menu items"<<endl;
        }
    
    }
    //Display/Output all pertinent variables
    
    //Exit the program
    return 0;
}