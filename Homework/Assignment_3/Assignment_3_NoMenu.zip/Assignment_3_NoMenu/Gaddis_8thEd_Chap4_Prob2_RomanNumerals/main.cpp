/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on August 29, 2017, 12:01 PM
 * Purpose: Creating our class template
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    short num; //Number to be converted to Roman Numeral
    
    //Input Data/Variables
    cout<<"This program converts numbers 1 to 10 to Roman Numerals"<<endl;
    cout<<"Please enter a number from 1 to 10"<<endl;
    cin>>num;
    cout<<endl;
    
    //Process or map the inputs to the outputs
    switch(num){
        
        case  1: cout<<"The Roman Numeral for 1 is i"<<endl;break;
        
        case  2: cout<<"The Roman Numeral for 2 is ii"<<endl;break;
        
        case  3: cout<<"The Roman Numeral for 3 is iii"<<endl;break;
        
        case  4: cout<<"The Roman Numeral for 4 is iv"<<endl;break;
        
        case  5: cout<<"The Roman Numeral for 5 is v"<<endl;break;
        
        case  6: cout<<"The Roman Numeral for 6 is vi"<<endl;break;
        
        case  7: cout<<"The Roman Numeral for 7 is vii"<<endl;break;
        
        case  8: cout<<"The Roman Numeral for 8 is viii"<<endl;break;
        
        case  9: cout<<"The Roman Numeral for 9 is ix"<<endl;break;
        
        case 10: cout<<"The Roman Numeral for 10 is x"<<endl;break;
        
        default: cout<<"Invalid input"<<endl;
    }
    
    //Display/Output all pertinent variables
    
    //Exit the program
    return 0;
}