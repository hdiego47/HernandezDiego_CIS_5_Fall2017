/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on October 11, 2017, 2:23 PM
 * Purpose: To find the days of the month
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    int month,year;
    
    //Input Data/Variables
    cout<<"This program tells you how many days are in a month"<<endl;
    cout<<"Please enter a month then a year"<<endl;
    cin>>month>>year;
    
    //Process or map the inputs to the outputs
    if(month==1)cout<<"January has 31 days"<<endl;
    if(month==2){
        if(year%100==0&&year%400==0)cout<<"February has 29 days"<<endl;
        else if(year%100!=0&&year%4==0)cout<<"February has 29 days"<<endl;
        else cout<<"February has 28 days"<<endl;
    }
    if(month==3)cout<<"March has 31 days"<<endl;
    if(month==4)cout<<"April has 30 days"<<endl;
    if(month==5)cout<<"May has 31 days"<<endl;
    if(month==6)cout<<"June has 30 days"<<endl;
    if(month==7)cout<<"July has 31 days"<<endl;
    if(month==8)cout<<"August has 31 days"<<endl;
    if(month==9)cout<<"September has 30 days"<<endl;
    if(month==10)cout<<"October has 31 days"<<endl;
    if(month==11)cout<<"November has 30 days"<<endl;
    if(month==12)cout<<"December has 31 days"<<endl;
    
    //Display/Output all pertinent variables
    
    //Exit the program
    return 0;
}