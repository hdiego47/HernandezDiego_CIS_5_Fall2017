/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on October 3, 2017, 11:52 AM
 * Purpose: To find the smallest and biggest number
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    int num1,num2;  //The two numbers to be entered
    int big,small; //The bigger and smaller numbers
    
    //Input Data/Variables
    cout<<"This program determines which number is larger and which is smaller"<<endl;
    cout<<"Please enter two numbers"<<endl;
    cin>>num1>>num2;
    cout<<endl;
    
    //Process or map the inputs to the outputs
    big=num1>num2?num1:num2;
    small=num1<num2?num1:num2;
    
    //Display/Output all pertinent variables
    cout<<"The two numbers entered were "<<num1<<" and "<<num2<<endl;
    cout<<"The bigger number was  "<<big<<endl;
    cout<<"The smaller number was "<<small<<endl;
    
    //Exit the program
    return 0;
}