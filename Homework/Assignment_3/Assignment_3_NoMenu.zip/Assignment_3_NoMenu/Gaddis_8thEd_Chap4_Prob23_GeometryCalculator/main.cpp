/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on October 11, 2017, 11:57 PM
 * Purpose: To make a geometry calculator
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
#include <cmath>     //Math library
#include <iomanip>   //format library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants
const float PI=3.14159f;

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    short menu;
    
    //Input Data/Variables
    cout<<"Choose a program to run"<<endl;
    cout<<"1. Calculate the Area of a Circle"<<endl;
    cout<<"2. Calculate the Area of a Rectangle"<<endl;
    cout<<"3. Calculate the Area of a Triangle"<<endl;
    cout<<"4. Quit"<<endl;
    cin>>menu;
    cout<<endl;
    
    //The geometry calculator
    cout<<fixed<<setprecision(1)<<showpoint;
    switch(menu){
        case 1:{
            float rad;  //The radius of the circle
            float area; //The area of the circle
            cout<<"Enter the radius of the circle"<<endl;
            cout<<"Negative numbers are not valid"<<endl;
            cin>>rad;
            if(rad<0)cout<<"You entered an invalid number"<<endl;
            else{ area=PI*pow(rad,2);
            cout<<"The Area of the Circle is "<<area<<endl;
            }
        }break;
        
        case 2:{
            int lngth;
            int wdth;
            int area;
            cout<<"Enter the length then the width of the rectangle"<<endl;
            cout<<"Negative numbers are not valid"<<endl;
            cin>>lngth>>wdth;
            if(lngth<0||wdth<0)cout<<"You entered an invalid number"<<endl;
            else {area=lngth*wdth;
            cout<<"The area of the rectangle is "<<area<<endl;
            }
        }break;
        
        case 3:{
            float area;
            float base;
            float hight;
            cout<<"Enter the base then the hight of the triangle"<<endl;
            cout<<"Negative numbers are not valid"<<endl;
            cin>>base>>hight;
            if(base<0||hight<0)cout<<"You entered an invalid number"<<endl;
            else {area=.5*base*hight;
            cout<<"The area of the triangle is "<<area<<endl;
            }
        }break;
        
        case 4:{
            cout<<"The program has ended"<<endl;
            
        }break;
        default: cout<<"You have entered an invalid number"<<endl;
    }

    //Exit the program
    return 0;
}