/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on October 4, 2017, 8:07 PM
 * Purpose: To calculate if a person is overweight, underweight or healthy using
 *          their BMI
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
#include <cmath>     //Math library
#include <iomanip>   //format library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float wt,ht,bmi;  //The person's weight height and BMI
    
    //Input Data/Variables
    cout<<"This program tells you if you are healthy using your BMI"<<endl;
    cout<<"Please enter your weight pounds then your height in inches"<<endl;
    cin>>wt>>ht;
    
    //Process or map the inputs to the outputs
    bmi=wt*703/pow(ht,2);
    cout<<fixed<<setprecision(1)<<showpoint;
    if(bmi<18.5){
        cout<<"Your BMI is "<<bmi<<endl;
        cout<<"According to your BMI you are underweight"<<endl;
    }else if(bmi>=18.5&&bmi<=25){
        cout<<"Your BMI is "<<bmi<<endl;
        cout<<"According to your BMI you have optimal weight"<<endl;
    }else{
        cout<<"Your BMI is "<<bmi<<endl;
        cout<<"According to your BMI you are overweight"<<endl;
    }
    
    //Display/Output all pertinent variables
    
    //Exit the program
    return 0;
}