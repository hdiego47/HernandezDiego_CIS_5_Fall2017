/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on October 4, 2017, 7:40 PM
 * Purpose: To compare the areas of rectangles
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    int lngth1,lngth2;  //the length of the two rectangles
    int wdth1,wdth2;    //The width of the two rectangles
    int area1,area2;    //The area of the two rectangles
    int big,small;      //The larger area and the smaller area
    
    //Input Data/Variables
    cout<<"This program finds which rectangle's area is bigger or if they are equal"<<endl;
    cout<<"Please enter the length then the width of the first rectangle in feet"<<endl;
    cin>>lngth1>>wdth1;
    cout<<"Now enter the length then the width of the second rectangle in feet"<<endl;
    cin>>lngth2>>wdth2;
    
    //Process or map the inputs to the outputs and display the data
    area1=lngth1*wdth1;
    area2=lngth2*wdth2;
    if(area1>area2){
        cout<<"Rectangle 1's area is "<<area1<<" ft^2"<<endl;
        cout<<"Rectangle 2's area is "<<area2<<" ft^2"<<endl;
        cout<<"Rectangle 1's area is larger than Rectangle 2's area"<<endl;
    }else if(area2>area1){
        cout<<"Rectangle 1's area is "<<area1<<" ft^2"<<endl;
        cout<<"Rectangle 2's area is "<<area2<<" ft^2"<<endl;
        cout<<"Rectangle 2's area is larger than Rectangle 1's area"<<endl;
    }else{ 
        cout<<"Rectangle 1's area is "<<area1<<" ft^2"<<endl;
        cout<<"Rectangle 2's area is "<<area2<<" ft^2"<<endl;
        cout<<"The area of both rectangles is equal"<<endl;
    }
    //Exit the program
    return 0;
}