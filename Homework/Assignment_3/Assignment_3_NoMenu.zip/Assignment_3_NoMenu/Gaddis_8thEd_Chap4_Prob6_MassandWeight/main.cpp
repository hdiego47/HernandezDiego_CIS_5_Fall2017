/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on September 20, 2017, 9:43 PM
 * Purpose: Creating our class template
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float mass;
    float weight;
    float grav=9.8f;
    
    //Input Data/Variables
    cout<<"This program calculates the weight of an object"<<endl;
    cout<<"Enter the mass of the object"<<endl;
    cin>>mass;
    cout<<endl;
    
    //Process or map the inputs to the outputs
    weight=mass*grav;
    cout<<"The mass of the object is "<<weight<<endl;
    if(weight>1000)cout<<"The object is too heavy"<<endl;
    if(weight<10)cout<<"The object is too light"<<endl;
    
    //Display/Output all pertinent variables
    
    //Exit the program
    return 0;
}