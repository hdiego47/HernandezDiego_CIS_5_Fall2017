/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on October 11, 2017, 1:21 PM
 * Purpose: To find how far the sound travels in different gasses
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    short menu;
    
    //Input Data/Variables
    cout<<"Choose the medium"<<endl;
    cout<<"1. Carbon Dioxide"<<endl;
    cout<<"2. Air"<<endl;
    cout<<"3. Helium"<<endl;
    cout<<"4. Hydrogen"<<endl;
    cin>>menu;
    cout<<endl;
    
    //Process or map the inputs to the outputs
    switch(menu){
        case 1:{
            float time;
            float speed=258.0f;
            float dist;
            cout<<"Enter the number of seconds it took for the sound to move"<<endl;
            cin>>time;
            if(time<0||time>30){cout<<"Time can not be greater than 30 seconds";
            cout<<"or less than 0 seconds"<<endl;
            }
            else {dist=time*speed;
            cout<<"The source of the sound was "<<dist<<" meters away"<<endl;
            }
        }break;
        
        case 2:{
            float time;
            float speed=331.5f;
            float dist;
            cout<<"Enter the number of seconds it took for the sound to move"<<endl;
            cin>>time;
            if(time<0||time>30){cout<<"Time can not be greater than 30 seconds";
            cout<<"or less than 0 seconds"<<endl;
            }
            else {dist=time*speed;
            cout<<"The source of the sound was "<<dist<<" meters away"<<endl;
            }
        }break;
        
        case 3:{
            float time;
            float speed=972.0f;
            float dist;
            cout<<"Enter the number of seconds it took for the sound to move"<<endl;
            cin>>time;
            if(time<0||time>30){cout<<"Time can not be greater than 30 seconds";
            cout<<"or less than 0 seconds"<<endl;
            }
            else {dist=time*speed;
            cout<<"The source of the sound was "<<dist<<" meters away"<<endl;
            }
        }break;
        
        case 4:{
            float time;
            float speed=1270.0f;
            float dist;
            cout<<"Enter the number of seconds it took for the sound to move"<<endl;
            cin>>time;
            if(time<0||time>30){cout<<"Time can not be greater than 30 seconds";
            cout<<"or less than 0 seconds"<<endl;
            }
            else {dist=time*speed;
            cout<<"The source of the sound was "<<dist<<" meters away"<<endl;
            }
        }break;
        
        default: cout<<"Invalid choice"<<endl;
    }
    //Display/Output all pertinent variables
    
    //Exit the program
    return 0;
}