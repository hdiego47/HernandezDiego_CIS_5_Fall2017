/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on October 3, 2017, 12:34 PM
 * Purpose: Magic Dates
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    short month,day,year;  //The date to be inputed
    
    //Input Data/Variables
    cout<<"Please enter a month (in numeric form),day,and two digit year"<<endl;
    cin>>month>>day>>year;
    cout<<endl;
    
    //Process or map the inputs to the outputs
    if(month*day==year)cout<<"The date is magic!"<<endl;
    else cout<<"The date is not magic..."<<endl;
    
    //Display/Output all pertinent variables
    
    //Exit the program
    return 0;
}