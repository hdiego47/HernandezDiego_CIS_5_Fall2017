/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on September 17, 2017, 12:30 PM
 * Purpose: To add and store numbers in variables
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    short numOne=50;  //First number to be added
    short numTwo=100; //Second number to be added
    short total;      //Sum of the two numbers
    
    //Process or map the inputs to the outputs
    total= numOne+numTwo;
    
    //Display/Output all pertinent variables
    cout<<"The sum of the two numbers is "<<total<<endl;
    
    //Exit the program
    return 0;
}