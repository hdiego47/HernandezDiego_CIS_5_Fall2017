/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on September 17, 2017, 1:13 PM
 * Purpose: To find the average of a set of values
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    short a=28;        //first value
    short b=32;        //second value
    short c=37;        //third value
    short d=24;        //fourth value
    short e=33;        //fifth value
    float sum,average; //sum and average of the values
    
    //Process or map the inputs to the outputs
    sum=a+b+c+d+e;
    average=sum/5;
    
    //Display/Output all pertinent variables
    cout<<"The values are               "
            <<a<<","<<b<<","<<c<<","<<d<<" and "<<e<<endl;
    cout<<"The sum of the values is     "<<sum<<endl;
    cout<<"The average of the values is "<<average<<endl;
    
    //Exit the program
    return 0;
}