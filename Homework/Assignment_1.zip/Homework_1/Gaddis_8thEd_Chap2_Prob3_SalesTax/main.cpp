/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on September 17, 2017, 12:44 PM
 * Purpose: To calculate the total sales tax on a $95 purchase
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float bValue=95;    //The amount of the purchase is $'s
    float pcStTax=.04f; //The percent state tax
    float pCtrTax=.02f; //The percent country tax
    float stTax,ctrTax,ttlTax; //The state, country and total tax in $'s
    float total;               //The total for the purchase including tax
    
    //Process or map the inputs to the outputs
    stTax=bValue*pcStTax;
    ctrTax=bValue*pCtrTax;
    ttlTax=stTax+ctrTax;
    total=bValue+ttlTax;
    
    //Display/Output all pertinent variables
    cout<<"The base value of the purchase is    $"<<bValue<<endl;
    cout<<"The percent state tax is              "<<pcStTax*100<<"%"<<endl;
    cout<<"The percent country tax is            "<<pCtrTax*100<<"%"<<endl;
    cout<<"The total state tax is               $"<<stTax<<endl;
    cout<<"The total country tax is             $"<<ctrTax<<endl;
    cout<<"The total tax for the purchase is    $"<<ttlTax<<endl;
    cout<<"The total amount for the purchase is $"<<total<<endl;
    
    //Exit the program
    return 0;
}