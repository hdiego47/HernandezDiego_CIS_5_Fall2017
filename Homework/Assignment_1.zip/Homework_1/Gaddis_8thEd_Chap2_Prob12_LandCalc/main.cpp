/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on August 31, 2017, 11:43 PM
 * Purpose: Land Calculation Acres/Miles^2
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants
const float CNVFTM=1.0/5280/5280;   //conversion from feet^2 to miles^2
const float CNVFTA=1.0/43560;       //conversion from feet^2 to acres

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float nft2,nacres,nmiles2;
    
    //Initialize Variables by inputing from the command line
    cout<<"This Program converts feet^2 to acres and miles^2"<<endl;
    cout<<"Input the feet^2 area to convert"<<endl;
    cin>>nft2;
    
    //Process or map the inputs to the outputs
    nacres=nft2*CNVFTA;
    nmiles2=nft2*CNVFTM;
    
    //Display/Output all pertinent variables
    cout<<nft2<<" square feet = "<<nacres<<" acres"<<endl;
    cout<<nft2<<" square feet = "<<nmiles2<<" square miles"<<endl;
    
    //Exit the program
    return 0;
}