/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on September 17, 2017, 12:59 PM
 * Purpose: To calculate the bill at a restaurant
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float mCharge=88.67f;      //the base amount owed in $'s
    float tax=.0675f;          //The percent tax
    float tip=.20f;            //The percent tip
    float ttlTip,ttlTax,total; //The total tip, tax, and amount including tip/tax
                               //in $'s
    
    //Process or map the inputs to the outputs
    ttlTip=mCharge*tip;
    ttlTax=mCharge*tax;
    total=mCharge+ttlTip+ttlTax;
    
    //Display/Output all pertinent variables
    cout<<"The base meal charge is   $"<<mCharge<<endl;
    cout<<"The tax percent is         "<<tax*100<<"%"<<endl;
    cout<<"The tip percent is         "<<tip*100<<"%"<<endl;
    cout<<"The total tip is          $"<<ttlTip<<endl;
    cout<<"The total tax is          $"<<ttlTax<<endl;
    cout<<"The total for the meal is $"<<total<<endl;
    
    //Exit the program
    return 0;
}