/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on September 25, 2017, 3:30 PM
 * Purpose: To create a word game
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    string name;     //person's name
    string age;      //person's age
    string city;     //city they live in
    string college;  //college they attended
    string prof;     //name of their profession
    string animal;   //type of animal they have as pet
    string pName;    //their pet's name
    
    //Input Data/Variables
    cout<<"This program plays a word game with the user."<<endl;
    cout<<"Please enter these in order: your name, your age, a city, a college,"<<endl;
    cout<<"a profession, a(n) animal, and a pet's name."<<endl;
    cout<<"Press Enter after every input."<<endl;
    getline(cin, name);
    getline(cin, age);
    getline(cin, city);
    getline(cin, college);
    getline(cin, prof);
    getline(cin, animal);
    getline(cin, pName);
    cout<<endl;
    
    //Display/Output all pertinent variables
    cout<<"There once was a person named "<<name<<" who lived in "<<city<<"."<<endl;
    cout<<"At the age of "<<age<<" "<<name<<" went to college at "<<college<<"."<<endl;
    cout<<name<<" graduated and went to work as a "<<prof<<"."<<endl;
    cout<<"Then, "<<name<<" adopted a(n) "<<animal<<" named "<<pName<<"."<<endl;
    cout<<"They both lived happily ever after!"<<endl;
    
    //Exit the program
    return 0;
}