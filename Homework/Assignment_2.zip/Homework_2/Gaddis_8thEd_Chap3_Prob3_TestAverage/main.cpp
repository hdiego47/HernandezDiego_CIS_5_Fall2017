/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on September 22, 2017, 8:57 PM
 * Purpose: To find the average of five test scores
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
#include <iomanip>   //format library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float score1,score2,  //The test five test scores
          score3,score4,
          score5;
    float average;        //The average of the test scores
    
    //Input Data/Variables
    cout<<"This program finds the average of five test scores"<<endl;
    cout<<"Please enter five test scores"<<endl;
    cin>>score1>>score2>>score3>>score4>>score5;
    
    //Process or map the inputs to the outputs
    average=(score1+score2+score3+score4+score5)/5;
    
    //Display/Output all pertinent variables
    cout<<fixed<<setprecision(1)<<showpoint;
    cout<<"The test scores that you entered were : "<<score1<<" "<<score2<<" "<<
            score3<<" "<<score4<<" "<<score5<<endl;
    cout<<"The average of the scores is "<<average<<endl;
    
    //Exit the program
    return 0;
}