/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on September 22, 2017, 9:13 PM
 * Purpose: To find how many slices any size pizza can be cut into
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
#include <cmath>     //Math library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants
const float PI=3.14f;  //Pi

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float pizzaD;           //The diameter of the pizza in inches
    float pizzaR;           //The radius of the pizza in inches
    float pizzaA;           //The area of the pizza in inches^2
    float areaSlc=14.125f;  //The area each slice should have
    float slices;           //The number of slices of pizza
    
    //Input Data/Variables
    cout<<"This program calculates how many slices a pizza can be cut into"<<endl;
    cout<<"Please enter the diameter of the pizza in inches"<<endl;
    cin>>pizzaD;
    
    //Process or map the inputs to the outputs
    pizzaR=pizzaD/2;
    pizzaA=PI*pow(pizzaR,2);
    slices=pizzaA/areaSlc;
    
    //Display/Output all pertinent variables
    cout<<"The diameter of the pizza is                      "<<pizzaD<<endl;
    cout<<"The radius of the pizza is                        "<<pizzaR<<endl;
    cout<<"The area of the pizza is                          "<<pizzaA<<endl;
    cout<<"The area per slice is                             "<<areaSlc<<endl;
    cout<<"The amount of slices the pizza can be cut into is "<<slices<<endl;
    
    //Exit the program
    return 0;
}