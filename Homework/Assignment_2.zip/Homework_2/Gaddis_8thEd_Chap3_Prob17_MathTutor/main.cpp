/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on September 19, 2017, 12:24 PM
 * Purpose: To create a math tutor
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
#include <cmath>     //math library
#include <iomanip>   //format library
#include <cstdlib>   //Random number library
#include <ctime>     //set the random number seed
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //set the random number seed
    srand(static_cast<unsigned int>(time(0)));
    
    //Declare Variables
    unsigned short op1,op2,stuAns,result;
    
    //initialize variables
    op1=rand()%900+100;//[100-999] 3 digit random number
    op2=rand()%900+100;//[100-999] 3 digit random number
    
    //Prompt for the result
    cout<<"This program tests your addition capability"<<endl;
    cout<<"Type the answer"<<endl;
    cout<<setw(6)<<op1<<endl;
    cout<<"+"<<setw(5)<<op2<<endl;
    cout<<"------"<<endl;
    cin>>stuAns;
    
    //Calculate the result
    result=op1+op2;
    
    //Output the result
    cout<<"The result = "<<result<<endl;
    cout<<((result==stuAns)?"Correct":"Incorrect")<<endl;
    
    //Exit the program
    return 0;
}