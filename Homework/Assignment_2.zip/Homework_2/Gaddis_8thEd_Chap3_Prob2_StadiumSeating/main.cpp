/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on September 20, 2017, 10:01 AM
 * Purpose: To find total amount of income generated from ticket sales
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
#include <iomanip>   //
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float classA=15.00f;     //Price of a class A ticket in $'s
    float classB=12.00f;     //Price of a class B ticket in $'s
    float classC=9.00f;      //Price of a class C ticket in $'s
    float soldA,soldB,soldC; //Amount of each ticket sold
    float totA,totB,totC;    //Total amount of money made from each ticket's sale
    float total;             //Total amount of income made from ticket sales
    
    //Input Data/Variables
    cout<<"This program calculates the total income generated from ticket sales"<<endl;
    cout<<"Please enter the total amount of sales for each ticket class"<<endl;
    cout<<"They must be entered in this order: Class A,Class B,Class C"<<endl;
    cin>>soldA>>soldB>>soldC;
    
    //Process or map the inputs to the outputs
    totA=soldA*classA;
    totB=soldB*classB;
    totC=soldC*classC;
    total=totA+totB+totC;
    
    //Display/Output all pertinent variables
    cout<<fixed<<setprecision(2)<<showpoint;
    cout<<"The total amount of tickets sold were:"<<endl<<endl;
    cout<<"                   Class A       Class B       Class C      "<<endl;
    cout<<"Price              $"<<classA<<"        $"
            <<classB<<"         $"<<classC<<endl<<endl;
    cout<<"Amount Sold    "<<setw(10)<<soldA<<"   "
            <<setw(10)<<soldB<<"    "<<setw(10)<<soldC<<endl<<endl;
    cout<<"Revenue/Class  $"<<setw(10)<<totA<<
            " $"<<setw(10)<<totB<<"    $"<<setw(10)<<totC<<endl;
    cout<<"------------------------------------------------------------"<<endl;
    cout<<"Total         $"<<total<<endl;
    
    //Exit the program
    return 0;
}