/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on September 19, 2017, 11:24 PM
 * Purpose: To calculate the monthly payment
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
#include <cmath>     //math library
#include <iomanip>   //format library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float n=36;    //The number of months to pay off the loan
    float i=.12f;  //The percent payed/year
    float l=10000; //The loan amount
    float mp,totPaid,intPaid; //The monthly payment,Total Paid and interest paid
    
    //Process or map the inputs to the outputs
    i=i/12;                              //convert to payed/month
    mp=(i*pow(1+i,n))/(pow(1+i,n)-1)*l;  //find monthly payed
    mp=static_cast<int>(mp*100)/100.0f;  //convert to pennies then back
    totPaid=mp*n;                        //find the total amount paid
    intPaid=totPaid-l;                   //find the total interest paid
    
    //Display/Output all pertinent variables
    cout<<"The number of months to pay off loan is  "<<n<<endl;
    cout<<setprecision(2)<<fixed<<showpoint;
    cout<<"The percent payed per year is            "<<i*100<<"%"<<endl;
    cout<<"The loan amount is                      $"<<l<<endl<<endl;
    cout<<"The monthly payment is                  $"<<mp<<endl;
    cout<<"The total paid is                       $"<<totPaid<<endl;
    cout<<"The interest paid is                    $"<<intPaid<<endl;
    
    //Exit the program
    return 0;
}