/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on September 20, 2017, 9:43 AM
 * Purpose: To calculate a car's gas mjleage.
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float gasHold;  //Gallons of gas the car can hold
    float miles;    //Miles the car can run on a full tank of gas
    float mpg;      //The miles per gallon of the car
    
    //Input Data/Variables
    cout<<"This program calculates the Miles per Gallon of a car"<<endl;
    cout<<"Please enter the amount of gallons of gas the car can hold"<<endl; 
    cout<<"then enter the amount of miles it can be driven in a full tank"<<endl;
    cin>>gasHold>>miles;
    
    //Process or map the inputs to the outputs
    mpg=miles/gasHold;
    
    //Display/Output all pertinent variables
    cout<<"The total amount of gas the car can hold is           "<<gasHold<<endl;
    cout<<"The total amount of miles it can go on a full tank is "<<miles<<endl;
    cout<<"The total Miles per Gallon that the car has is        "<<mpg<<" MPG"<<endl;
    
    //Exit the program
    return 0;
}