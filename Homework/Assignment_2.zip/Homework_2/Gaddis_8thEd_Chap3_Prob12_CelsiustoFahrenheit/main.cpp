/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on September 25, 2017, 3:43 PM
 * Purpose: To convert Celsius to Fahrenheit
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
#include <iomanip>   //Format library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float cels;  //The temperature in Celsius
    float fahr;  //The temperature in Fahrenheit
    
    //Input Data/Variables
    cout<<"This program converts Celsius temperatures to Fahrenheit"<<endl;
    cout<<"Please enter the temperature in Celsius"<<endl;
    cin>>cels;
    cout<<endl;
    
    //Process or map the inputs to the outputs
    fahr=cels*9/5+32;
    
    //Display/Output all pertinent variables
    cout<<fixed<<setprecision(1)<<showpoint;
    cout<<"The temperature in Celsius is    "<<cels<<" degrees"<<endl;
    cout<<"The temperature in Fahrenheit is "<<fahr<<" degrees"<<endl;
    
    //Exit the program
    return 0;
}