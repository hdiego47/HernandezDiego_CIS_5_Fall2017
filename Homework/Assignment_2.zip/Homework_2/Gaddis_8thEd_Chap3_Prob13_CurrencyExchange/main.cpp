/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on September 20, 2017, 9:43 PM
 * Purpose: Creating our class template
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
#include <iomanip>   //Format library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants
const float DOLLEU=.84f;     //Conversion from dollar to euro
const float DOLLYEN=111.99f; //Conversion from dollar to yen

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float dollars;
    float yen;
    float euros;
    
    //Input Data/Variables
    cout<<"This program converts Dollars to Yen and Euros"<<endl;
    cout<<"Please enter the amount you want to convert in Dollars"<<endl;
    cin>>dollars;
    
    //Process or map the inputs to the outputs
    euros=dollars*DOLLEU;
    yen=dollars*DOLLYEN;
    
    //Display/Output all pertinent variables
    cout<<fixed<<setprecision(2)<<showpoint;
    cout<<"$"<<dollars<<" converts to "<<euros<<" Euros"<<endl;
    cout<<"$"<<dollars<<" converts to "<<yen<<" Yen"<<endl;
    
    
    //Exit the program
    return 0;
}